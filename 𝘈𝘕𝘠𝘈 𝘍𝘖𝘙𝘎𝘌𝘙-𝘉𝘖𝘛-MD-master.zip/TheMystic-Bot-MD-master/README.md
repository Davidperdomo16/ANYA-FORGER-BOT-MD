# `🧿 𝚃𝚑𝚎 𝙼𝚢𝚜𝚝𝚒𝚌 - 𝙱𝚘𝚝 🔮`

## El Bot ya no recibirá mas actualizaciones

### `—◉ 👑 DUDAS SOBRE EL BOT?, CONTACTAME 👑`
<a href="http://wa.me/5219992095479" target="blank"><img src="https://img.shields.io/badge/BRUNO_SOBRINO-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" /></a>
> NO BOT

### `—◉ ✨ ACTIVAR EN HEROKU ✨`
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/BrunoSobrino/TheMystic-Bot-MD)
```bash
AÑADE AL APARTADO DE BUILPACK LO SIGUIENTE, SI YA APARCEN SOLO IGNORA ESTA PARTE:
> heroku/nodejs
> https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest.git
> https://github.com/clhuang/heroku-buildpack-webp-binaries.git
> https://github.com/DuckyTeam/heroku-buildpack-imagemagick.git
ADVERTENCIA: HEROKU ESTA SUSPENDIENDO CUENTAS POR SOLO USAR EL BOT, POR AHORA NO ES RECOMENDABLE USAR EL BOT EN HEROKU!
```

### `—◉ ⚙️ AJUSTES ⚙️`
- CLONAR EL REPOSITORIO [Aqui](https://github.com/BrunoSobrino/TheMystic-Bot-MD/fork)
- CAMBIAR NÚMERO DEL OWNER [Aqui](https://github.com/BrunoSobrino/TheMystic-Bot-MD/blob/master/config.js)

### `—◉ 👾 ACTIVAR EN TERMUX 👾`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd
> termux-setup-storage
> apt update 
> pkg upgrade 
> pkg install git -y
> pkg install nodejs -y
> pkg install ffmpeg -y
> pkg install imagemagick -y
> pkg install yarn
> git clone https://github.com/BrunoSobrino/TheMystic-Bot-MD
> cd TheMystic-Bot-MD
> npm install
> yarn install 
> npm install
> npm update
> npm start
```

### `—◉ ✔️ ACTIVAR EN CASO DE DETENERSE ✔️`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> cd TheMystic-Bot-MD
> npm start
```

### `—◉ 👽 OBTENER OTRO CODIGO QR 👽`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> cd TheMystic-Bot-MD
> rm -rf session.data.json
> npm start
```

### `—◉ 🔥 ACTIVAR EN BOXMINEHOST 🔥`
<img src="https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/Pre%20Bot%20Publi.png" alt="GIF" width="450" height="240"/>
<p>> Pagina Oficial:
<a href="https://boxmineworld.com">https://boxmineworld.com</a>
<p>> Dashboard:
<a href="https://dash.boxmineworld.com/home">https://dash.boxmineworld.com/home</a>
<p>> Panel:
<a href="https://panel.boxmineworld.com">https://panel.boxmineworld.com</a>
<p>> Tutorial:
<a href="https://youtu.be/eC9TfKICpcY">https://youtu.be/eC9TfKICpcY</a>
<p>> Dudas UNICAMENTE SOBRE EL HOST:
<a href="https://discord.gg/84qsr4v">https://discord.gg/84qsr4v</a> (Preguntar por Vicemi)
</p>

### `—◉ 📝 NOTAS 📝`
```bash
- ES POSIBLE QUE EL BOT TENGA ALGUNAS FALLAS, SE IRAN SOLUCIONANDO CONFORME SE VAYAN DETECTANDO
- ES RECOMENDABLE LEER TODO EL MENU Y VER EL FUNCIONAMIENTO DE CADA UNO DE LOS COMANDOS
- REPORTA CUALQUIER FALLO CON EL COMANDO DE REPORTE 
- PARA PODER ESCANEAR EL CODIGO QR DEBES SER PARTICIPANTE DE LA VERSION MULTI-DEVICE (BETA) DE WHATSAPP
- NO MODIFIQUES NADA QUE NO SEPAS PARA QUE ES, PARA EVITAR PROBLEMAS O ERRORES
- SI VAS A EDITAR POR COMPLETO DEJA LOS CREDITOS DEL BOT 
- EL BOT ES COMPARTIBLE CON WHATSAPP NORMAL O BUSINESS
- ATENTO A LAS ACTUALIZACIONES QUE SE HAGAN EN ESTE REPOSITORIO
- EL ADD Y EL KICK PUEDEN OCASIONAR QUE EL NUMERO SE VAYA A SOPORTE 
- EL BOT FUNCIONA AUNQUE EL WHATSAPP NO TENGA CONEXION 
- SE RECOMIENDA REESCANEAR EL CODIGO QR CADA 2 DIAS, PARA EVITAR PROBLEMAS O ERRORES
```

## `EDITOR Y PORPIETARIO DEL BOT` 
[![BrunoSobrino](https://avatars.githubusercontent.com/u/90165013?s=400&u=946f5c00c527c7e6fa2ef5148c6ad56270bb600e&v=4size=100)](https://github.com/BrunoSobrino/) 

`The Mystic - Bot __________ By Bruno Sobrino`

